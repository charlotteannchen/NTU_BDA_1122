import json
with open("code/annotations.json", "r") as file:
    data = json.load(file)
    
def transform_action(action, sequence, video_id):
    if action == "click":
        start_frame = sequence[0]["frame"]
        end_frame = sequence[-1]["frame"]
        down_coordinate = [sequence[0]["x"], sequence[0]["y"]]
        up_coordinate = [sequence[-1]["x"], sequence[-1]["y"]]
        return {
            "start_frame": str(start_frame),
            "end_frame": str(end_frame),
            "action_type": action,
            "down_coordinate": down_coordinate,
            "up_coordinate": up_coordinate,
            "type_word": None
        }
    if action == "swipe":
        start_frame = sequence[0]["frame"]
        end_frame = sequence[-1]["frame"]
        down_coordinate = [sequence[0]["x"], sequence[0]["y"]]
        up_coordinate = [sequence[-1]["x"], sequence[-1]["y"]]
        return {
            "start_frame": str(start_frame),
            "end_frame": str(end_frame),
            "action_type": action,
            "down_coordinate": down_coordinate,
            "up_coordinate": up_coordinate,
            "type_word": None
        }
    if action == "type" and video_id == 1:
        start_frame = sequence[0]["frame"]
        end_frame = sequence[-1]["frame"]
        return {
            "start_frame": str(start_frame),
            "end_frame": str(end_frame),
            "action_type": action,
            "down_coordinate": "null",
            "up_coordinate": "null",
            "type_word": "little women"
        }
    if action == "type" and video_id == 2:
        start_frame = sequence[0]["frame"]
        end_frame = sequence[-1]["frame"]
        return {
            "start_frame": str(start_frame),
            "end_frame": str(end_frame),
            "action_type": action,
            "down_coordinate": "null",
            "up_coordinate": "null",
            "type_word": "the great gatsby"
        }


# Placeholder for the transformed data
transformed_data = {}

# Transforming the data
for video in data:
    video_id = f"{video['id']}.mp4"
    actions = []

    for annotation in video["annotations"]:
        for result in annotation["result"]:
            action_type = result["value"]["labels"][0]
            sequence = result["value"]["sequence"]
            # print(video_id)
            action = transform_action(action_type, sequence, video['id'])
            if action:
                actions.append(action)
    
    transformed_data[video_id] = actions

# Convert the transformed data to JSON string for display
transformed_data_json = json.dumps(transformed_data, indent=2)
print(transformed_data_json)  # Print a part of the transformed data for brevity
with open("annotate.json", "w") as outfile:
    outfile.write(transformed_data_json)